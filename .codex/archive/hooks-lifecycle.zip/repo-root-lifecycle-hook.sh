#!/usr/bin/env bash
set -euo pipefail

event_raw="${1:-}"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
repo_root="$(cd -- "$script_dir/../.." && pwd -P)"
hooks_dir="$repo_root/.codex/hooks"
workspace_root="/home/flexnetos/FlexNetOS"
workspace_hook="$workspace_root/.codex/hooks/flexnetos-codex-hook.sh"

normalize_event() {
  case "$1" in
    session-start|SessionStart) printf 'session-start\n' ;;
    pre-tool-use|PreToolUse) printf 'pre-tool-use\n' ;;
    permission-request|PermissionRequest) printf 'permission-request\n' ;;
    post-tool-use|PostToolUse) printf 'post-tool-use\n' ;;
    user-prompt-submit|UserPromptSubmit) printf 'user-prompt-submit\n' ;;
    pre-compact|PreCompact) printf 'pre-compact\n' ;;
    post-compact|PostCompact) printf 'post-compact\n' ;;
    stop|Stop) printf 'stop\n' ;;
    subagent-start|SubagentStart) printf 'subagent-start\n' ;;
    subagent-stop|SubagentStop) printf 'subagent-stop\n' ;;
    *) printf '%s\n' "$1" ;;
  esac
}

event="$(normalize_event "$event_raw")"

run_bash_hook() {
  local script="$1"
  shift || true
  [ -x "$script" ] || return 0
  /bin/bash "$script" "$@"
}

run_python_hook() {
  local script="$1"
  [ -f "$script" ] || return 0
  /usr/bin/python3 "$script"
}

run_bun_native_hook() {
  local bun="$workspace_root/.toolchains/.bun/bin/bun"
  local script="$repo_root/dist/scripts/codex-native-hook.js"
  [ -x "$bun" ] || return 0
  [ -f "$script" ] || return 0
  "$bun" "$script"
}

run_meta_with_env() {
  local mode="$1"
  local with_env="$hooks_dir/with-meta-env.sh"
  [ -x "$with_env" ] || return 0
  case "$mode" in
    context)
      [ -x "$hooks_dir/meta-context-session-start.sh" ] || return 0
      "$with_env" "$hooks_dir/meta-context-session-start.sh"
      ;;
    guard)
      [ -x "$repo_root/agent/target/debug/agent" ] || return 0
      "$with_env" "$repo_root/agent/target/debug/agent" guard
      ;;
    stop)
      [ -x "$repo_root/agent/target/debug/agent" ] || return 0
      "$with_env" "$repo_root/agent/target/debug/agent" codex stop
      ;;
  esac
}

run_meta_gitkb_service() {
  [ -x "$hooks_dir/with-meta-env.sh" ] || return 0
  rtk bash -lc 'rtk git kb service status --quiet >/dev/null 2>/dev/null || rtk git kb service start >/dev/null 2>/dev/null'
}

run_runtime_gate() {
  run_bash_hook "$hooks_dir/flexnetos-runtime-gate.sh" "$event"
}

run_checkpoint() {
  run_bash_hook "$hooks_dir/hf-checkpoint.sh"
}

run_teri_context() {
  run_bash_hook "$hooks_dir/teri-context-session-start.sh"
}

if [ "$repo_root" = "$workspace_root" ] && [ -x "$workspace_hook" ] && [ "$workspace_hook" != "$0" ]; then
  exec /bin/bash "$workspace_hook" "$event"
fi

case "$event" in
  session-start)
    run_runtime_gate
    run_teri_context
    run_meta_with_env context
    run_meta_gitkb_service
    run_python_hook "$hooks_dir/forge_loop_session_start.py"
    run_bun_native_hook
    ;;
  pre-tool-use)
    run_runtime_gate
    run_meta_with_env guard
    run_python_hook "$hooks_dir/forge_loop_pre_tool_use.py"
    run_bun_native_hook
    ;;
  permission-request)
    run_runtime_gate
    run_python_hook "$hooks_dir/forge_loop_permission_request.py"
    ;;
  post-tool-use)
    run_runtime_gate
    run_python_hook "$hooks_dir/forge_loop_post_tool_use.py"
    run_bun_native_hook
    ;;
  user-prompt-submit)
    run_bun_native_hook
    ;;
  pre-compact)
    run_runtime_gate
    run_checkpoint
    run_teri_context
    run_meta_with_env context
    run_python_hook "$hooks_dir/forge_loop_compact_summary.py"
    run_bun_native_hook
    ;;
  post-compact)
    run_python_hook "$hooks_dir/forge_loop_compact_summary.py"
    run_bun_native_hook
    ;;
  stop)
    run_checkpoint
    run_runtime_gate
    run_meta_with_env stop
    run_python_hook "$hooks_dir/forge_loop_stop_summary.py"
    run_bun_native_hook
    ;;
  subagent-start|subagent-stop)
    run_python_hook "$hooks_dir/forge_loop_subagent_summary.py"
    ;;
esac
